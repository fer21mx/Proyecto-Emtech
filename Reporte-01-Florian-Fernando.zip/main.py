from lifestore_file import lifestore_searches
from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales

from collections import Counter 

#Búsquedas; alistando motores. 
lifestore_searches_assistant = []

for (índice) in lifestore_searches:
  if (índice[1]):
    lifestore_searches_assistant.append(índice[1])

contador_búsquedas = Counter(lifestore_searches_assistant)


lifestore_searches_assistant_copia = list(lifestore_searches_assistant)
productos_buscados= []
for n in lifestore_searches_assistant_copia:
  if n not in productos_buscados:
    productos_buscados.append(n)


#Para los artículos con más búsquedas
idproducto_búsquedas_más_comunes = contador_búsquedas.most_common(20)
búsquedas= []
for nombre in lifestore_products:
  for búsqueda in idproducto_búsquedas_más_comunes:
    if nombre[0] == búsqueda[0]:
      los_más_buscados = [nombre[1], búsqueda[1]]
      if nombre[1] and búsqueda[1] not in búsquedas:
        búsquedas.append(los_más_buscados)

ordenar_buscados = sorted(búsquedas, key=lambda veces_buscado : veces_buscado [1], reverse=True)
#print("Los 20 artículos más buscados son: ")
for limpio in ordenar_buscados:
  #print("El artículo:", limpio[0], "se buscó", limpio[1], "veces.")
  break
#print()

#Para los productos que tuvieron menos búsquedas
idproducto_búsquedas_menos_comunes = contador_búsquedas.most_common(len(contador_búsquedas))
menores_búsquedas= []
for nombre in lifestore_products:
  for búsqueda in idproducto_búsquedas_menos_comunes:
    if nombre[0] == búsqueda[0]:
      los_menos_buscados = [nombre[1], búsqueda[1]]
      if nombre[1] and búsqueda[1] not in menores_búsquedas:
        menores_búsquedas.append(los_menos_buscados)
ordenar_menos_buscados = sorted(menores_búsquedas, key=lambda menos_veces_buscado : menos_veces_buscado [1])
#print("Los 20 artículos menos buscados son:")
contador_asistente1 = 0
menos_buscados=[]
for elemento in ordenar_menos_buscados:
  if elemento not in menos_buscados and contador_asistente1 < 21:
    menos_buscados.append(elemento)
    contador_asistente1 += 1 

#print(menos_buscados)
  

#Para los productos que tuvieron 0 búsquedas.
números_rezagados = []

for x in list(range(97)):
  if x not in lifestore_searches_assistant_copia and x != 0 :
    números_rezagados.append(x)

los_rezagados = []
for nombres in lifestore_products:
  for rezagado in números_rezagados:
    if nombres[0] == rezagado:
      los_rezagados.append(nombres[1]) 
#print("Los productos rezagados son:")
#for limpieza in los_rezagados:
  #print(limpieza)

#Ventas: alistando motores
lifestore_sales_assistant = []

for (índice) in lifestore_sales:
  if (índice[1]):
    lifestore_sales_assistant.append(índice[1])


contador_ventas = Counter(lifestore_sales_assistant)


lifestore_sales_assistant_copia = list(lifestore_sales_assistant)
productos_vendidos= []
for n in lifestore_sales_assistant_copia:
  if n not in productos_vendidos:
    productos_vendidos.append(n)

#Para los artículos más vendidos.
idproducto_más_vendidos = contador_ventas.most_common(20)
ventas= []
for nombre in lifestore_products:
  for venta in idproducto_más_vendidos:
    if nombre[0] == venta[0]:
      los_más_vendidos = [nombre[1], venta[1]]
      if nombre[1] and venta[1] not in ventas:
        ventas.append(los_más_vendidos)

ordenar_vendidos = sorted(ventas, key=lambda veces_vendido : veces_vendido[1], reverse=True)
#print("Los 20 artículos más vendidos son: ")
#for limpio in ordenar_vendidos:
  #print("El artículo:", limpio[0], "tuvo", limpio[1], "ventas.")


#Para los productos menos vendidos.
idproducto_menos_vendidos = contador_ventas.most_common(len(contador_ventas))
menos_vendidos= []
for nombre in lifestore_products:
  for venta in idproducto_menos_vendidos:
    if nombre[0] == venta[0]:
      los_menos_vendidos = [nombre[1], venta[1]]
      if nombre[1] and venta[1] not in menos_vendidos:
        menos_vendidos.append(los_menos_vendidos)
ordenar_menos_vendidos = sorted(menos_vendidos, key=lambda menos_veces_vendido : menos_veces_vendido [1])

#print("Los 20 artículos menos vendidos son:")

contador_asistente2 = 0
menos_vendidos=[]
for elemento in ordenar_menos_vendidos:
  if elemento not in menos_vendidos and contador_asistente2 < 21:
    menos_vendidos.append(elemento)
    contador_asistente2 += 1 

#print(menos_vendidos)

#Para los productos que no se vendieron
productos_no_vendidos = []

for x in list(range(97)):
  if x not in lifestore_sales_assistant_copia and x != 0 :
    productos_no_vendidos.append(x)

los_no_vendidos = []
for nombres in lifestore_products:
  for rezagado in productos_no_vendidos:
    if nombres[0] == rezagado:
      los_no_vendidos.append(nombres[1]) 
#print("Los productos que no se vendieron son:")
#for limpieza in los_no_vendidos:
  #print(limpieza)

#Finanzas: 

#print(idproducto_más_vendidos)
precio_producto = []
numero_ventas = []
for produ in lifestore_products:
    for sale in idproducto_más_vendidos:
      if produ[0] == sale[0]:
        a = produ[2]
        precio_producto.append(a)
        b = sale[1]
        numero_ventas.append(b)

ab = []                        
for i in range(0, len(precio_producto)):
     ab.append(precio_producto[i]*numero_ventas[i])

def sumar(ab):
  suma = 0
  for w in ab:
    suma += w
  return suma
ingresos_netos_anuales = (sumar(ab)) 

promedio_ingresos_mensuales = ingresos_netos_anuales // 9









#Reseñas y productos 
producto_reseña_devolución=[]
for a in lifestore_sales:
  producto_reseña_devolucion=(a[1], a[2], a[4])
  if a[1] and a[2] and a[4] not in producto_reseña_devolución:
    producto_reseña_devolución.append(producto_reseña_devolucion)

mal_valorados=[]
for a in producto_reseña_devolución:
  if int(a[1]) < 4:
    mal_valorados.append(a)

#print("Los productos siguientes obtuvieron las peores reseñas:")
for producto in lifestore_products:
  for mal_valorado in mal_valorados:
    if producto[0] == mal_valorado[0]:
      lista_malas_reseñas = ("El producto", producto[1], "ha obtenido una calificación de" , mal_valorado[1])
      #print(lista_malas_reseñas)


bien_valorados = []
for a in producto_reseña_devolución:
  if int(a[1]) > 3:
    bien_valorados.append(a)
lista_buenas_reseñas = []
#print("Los productos siguientes obtuvieron las mejores reseñas, se muestra solo una vez por cada calificación obtenida, es decir, 4 o 5.")
for producto in lifestore_products:
  for bien_valorado in bien_valorados:
    if producto[0] == bien_valorado[0] and bien_valorado[1] not in lista_buenas_reseñas:
      lista_buenas_reseñas = ("El producto", producto[1], "ha obtenido una calificación de" , bien_valorado[1])
      #print(lista_buenas_reseñas)




















'Para el inicio de sesión'
usuarios_admin =[['1','2']]

usuarios_nuevos = []


pregunta1 = input('¿Eres administrador? Sí/No ') 
if pregunta1 == 'No':
  registro= input('¿Quieres registrarte?')
  if registro =='Sí':
    Nuevo_registro = input('Elige un nombre de usuario')
    Nueva_contraseña = input('Elige una contraseña')
    nuevos = (Nuevo_registro, Nueva_contraseña)
    usuarios_nuevos.append(nuevos)
    print('Gracias por registrarte')
    pregunta2 = input('¿Quieres ver nuestros productos?')
    if pregunta2 == 'Sí':
      print (lifestore_products)  
  if registro == 'No':
    print('Bueno, adiós')

  #Si mostramos los usuarios registrados
  #print(usuarios_nuevos)

if pregunta1 == 'Sí':
  usuario = input('Ingresa tu nombre de usuario: ')
  for a in usuarios_admin:
    if usuario == (a[0]):
      contraseña = input('Ahora escribe tu contraseña: ')
      for a in usuarios_admin:
        if contraseña == a[1]:
          print ('Bienvenido, Fernando')
          pregunta3 = input('¿Quieres ir al índice? ')
          if pregunta3 == 'Sí':
            print('Búsquedas')
            print('Ventas')
            print('Reseñas')
            print('Finanzas')
            pregunta4 = input('¿Qué quieres ver? ')
            if pregunta4 == 'Búsquedas':
              print('Los más buscados')
              print('Los menos buscados')
              print('Los rezagados, (productos que no se buscaron)')
              pregunta41 = input('¿A dónde quieres ir? ')
              if pregunta41 == 'Los más buscados':
                for limpio in ordenar_buscados:
                  print("El artículo:", limpio[0], "se buscó", limpio[1], "veces.")
              if pregunta41 == 'Los menos buscados': 
                print(menos_buscados)
              if pregunta41== 'Los rezagados':
                for limpieza in los_rezagados:
                  print(limpieza)
          pregunta3 = input('¿Quieres ir al índice? ')
          if pregunta3 == 'Sí':
            print('Búsquedas')
            print('Ventas')
            print('Reseñas')
            print('Finanzas')
            pregunta4 = input('¿A dónde quieres ir? ')
            if pregunta4 == 'Ventas':
              print('Los más vendidos')
              print('Los menos vendidos')
              print('Los que no se vendieron')
              pregunta51 = input('¿Qué quieres ver?')
              if pregunta51 == 'Los más vendidos':
                for limpio in ordenar_vendidos:
                  print("El artículo:", limpio[0], "tuvo", limpio[1], "ventas.")
              if pregunta51 == 'Los menos vendidos':
                print(menos_vendidos)
              if pregunta51 == 'Los que no se vendieron':
                for limpieza in los_no_vendidos:
                  print(limpieza)
          pregunta3 = input('¿Quieres ir al índice? ')
          if pregunta3 == 'Sí':
            print('Búsquedas')
            print('Ventas')
            print('Reseñas')
            print('Finanzas')
            pregunta4= input('¿A dónde quieres ir?')
            if pregunta4 == 'Reseñas':
              print('Los mejores valuados')
              print('Los peores valuados')
              pregunta61 = input('¿Qué quieres ver?')
              if pregunta61 == 'Los mejores valuados':
                for producto in lifestore_products:
                  for bien_valorado in bien_valorados:
                    if producto[0] == bien_valorado[0] and bien_valorado[1] not in lista_buenas_reseñas:
                      lista_buenas_reseñas = ("El producto", producto[1], "ha obtenido una calificación de" , bien_valorado[1])
                      print(lista_buenas_reseñas)
              if pregunta61 == 'Los peores valuados':
                for producto in lifestore_products:
                  for mal_valorado in mal_valorados:
                    if producto[0] == mal_valorado[0]:
                      lista_malas_reseñas = ("El producto", producto[1], "ha obtenido una calificación de" , mal_valorado[1])
                      print(lista_malas_reseñas)
          pregunta3 = input('¿Quieres ir al índice? ')
          if pregunta3 == 'Sí':
            print('Búsquedas')
            print('Ventas')
            print('Reseñas')
            print('Finanzas')
            pregunta4= input('¿A dónde quieres ir?') 
            if pregunta4 == 'Finanzas':
              print('El total de ingresos desde la última venta registrada, es decir, en noviembre del 2019, fue de ', ingresos_netos_anuales, 'pesos, por lo tanto, en nueve meses (periodo de noviembre 2019 - julio 2020) el promedio mensual de ingresos registrados fue de: ', promedio_ingresos_mensuales, 'pesos, sabiendo que el mes con peores ventas registradas fue diciembre 2019.')
          pregunta3 = input('¿Quieres ir al índice? ')
          if pregunta3 == 'Sí':
            print('Búsquedas')
            print('Ventas')
            print('Reseñas')
            print('Finanzas')
        if contraseña != a[1]:
          print('Contraseña incorrecta: ¿Eres tu Fernando?')
    if usuario != a[0]:
          print('Error, ingresa tus datos correctamente')
          break

     
    break